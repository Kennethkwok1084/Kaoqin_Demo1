from __future__ import annotations

from flask import Blueprint, g, request

from app.extensions import db
from app.models import SamplingRecord, SamplingScanDetail, SamplingTestDetail, TaskSampling, TaskSamplingRoom, TaskSamplingUser, TodoItem
from app.repositories.sampling_repository import SamplingRepository
from app.services.sampling_service import SamplingService
from app.services.workhour_service import WorkhourService
from app.utils.auth import login_required
from app.utils.response import api_error, api_success

bp = Blueprint("sampling", __name__)


@bp.post("")
@login_required(role="admin")
def create_sampling_task():
    payload = request.get_json(silent=True) or {}
    task = TaskSampling(
        task_code=payload["task_code"],
        title=payload["title"],
        description=payload.get("description"),
        building_id=payload["building_id"],
        target_room_count=payload["target_room_count"],
        sample_strategy=payload.get("sample_strategy", "weighted_random"),
        exclude_days=payload.get("exclude_days", 30),
        assigned_by=g.current_user.id,
        planned_start_at=payload.get("planned_start_at"),
        planned_end_at=payload.get("planned_end_at"),
        status=payload.get("status", 1),
    )
    db.session.add(task)
    db.session.flush()

    for user_id in payload.get("assignee_user_ids", []):
        db.session.add(TaskSamplingUser(sampling_task_id=task.id, user_id=user_id, role_in_task="executor"))

    generated_rooms = SamplingService.generate_rooms(task)
    db.session.commit()
    return api_success(
        {
            "task": task.to_dict(),
            "generated_rooms": [
                {"id": row.id, "dorm_room_id": row.dorm_room_id, "generated_weight": row.generated_weight}
                for row in generated_rooms
            ],
        },
        message="抽检任务创建并生成宿舍清单成功",
        http_status=201,
    )


@bp.get("/recent-records")
@login_required(role="admin")
def recent_records():
    rows = SamplingRepository.list_recent_records(limit=int(request.args.get("limit", 20)))
    return api_success(rows)


@bp.post("/<int:task_id>/records")
@login_required()
def submit_sampling_record(task_id: int):
    payload = request.get_json(silent=True) or {}
    task_room_id = payload.get("sampling_task_room_id")
    if not task_room_id:
        return api_error("sampling_task_room_id 不能为空", code=4001)

    record = SamplingRecord(
        sampling_task_id=task_id,
        sampling_task_room_id=task_room_id,
        dorm_room_id=payload["dorm_room_id"],
        user_id=g.current_user.id,
        detect_mode=payload.get("detect_mode", "full"),
        current_ssid=payload.get("current_ssid"),
        current_bssid=payload.get("current_bssid"),
        bssid_match=payload.get("bssid_match"),
        ipv4_addr=payload.get("ipv4_addr"),
        gateway_addr=payload.get("gateway_addr"),
        dns_list=payload.get("dns_list"),
        operator_name=payload.get("operator_name"),
        channel_no=payload.get("channel_no"),
        negotiated_rate_mbps=payload.get("negotiated_rate_mbps"),
        signal_strength_dbm=payload.get("signal_strength_dbm"),
        loss_rate_pct=payload.get("loss_rate_pct"),
        intranet_ping_ms=payload.get("intranet_ping_ms"),
        internet_ping_ms=payload.get("internet_ping_ms"),
        udp_jitter_ms=payload.get("udp_jitter_ms"),
        udp_loss_rate_pct=payload.get("udp_loss_rate_pct"),
        tcp_rtt_ms=payload.get("tcp_rtt_ms"),
        down_speed_mbps=payload.get("down_speed_mbps"),
        up_speed_mbps=payload.get("up_speed_mbps"),
        interference_score=payload.get("interference_score"),
        exception_auto=payload.get("exception_auto", False),
        exception_manual=payload.get("exception_manual", False),
        manual_exception_note=payload.get("manual_exception_note"),
        started_at=payload.get("started_at"),
        finished_at=payload.get("finished_at"),
    )
    db.session.add(record)
    db.session.flush()

    for row in payload.get("scan_details", []):
        db.session.add(SamplingScanDetail(sampling_record_id=record.id, **row))
    for row in payload.get("test_details", []):
        db.session.add(SamplingTestDetail(sampling_record_id=record.id, **row))

    task_room = TaskSamplingRoom.query.get(task_room_id)
    if task_room:
        task_room.is_completed = True
        task_room.completed_by = g.current_user.id
        task_room.completed_at = db.func.now()

    if record.exception_auto or record.exception_manual:
        db.session.add(
            TodoItem(
                todo_type="sampling_exception",
                source_biz_type="sampling_record",
                source_biz_id=record.id,
                title=f"抽检异常待处理: #{record.id}",
                content=record.manual_exception_note,
                priority_level=2,
                status=0,
            )
        )

    WorkhourService.create_entry(
        biz_type="sampling",
        biz_id=record.id,
        user_id=g.current_user.id,
        base_minutes=int(payload.get("base_minutes", 0)),
    )
    db.session.commit()
    return api_success(record.to_dict(), message="抽检结果提交成功", http_status=201)
