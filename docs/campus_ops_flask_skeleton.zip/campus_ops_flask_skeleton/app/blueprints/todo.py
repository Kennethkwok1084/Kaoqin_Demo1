from __future__ import annotations

from flask import Blueprint, request

from app.models import TodoItem
from app.utils.auth import login_required
from app.utils.pagination import build_page_payload
from app.utils.response import api_success

bp = Blueprint("todo", __name__)


@bp.get("")
@login_required(role="admin")
def list_todos():
    page = max(int(request.args.get("page", 1)), 1)
    page_size = min(max(int(request.args.get("page_size", 20)), 1), 100)
    query = TodoItem.query.order_by(TodoItem.created_at.desc())
    total = query.count()
    rows = query.offset((page - 1) * page_size).limit(page_size).all()
    return api_success(build_page_payload([row.to_dict() for row in rows], page, page_size, total))
