from __future__ import annotations

from flask import Flask

from .auth import bp as auth_bp
from .coop import bp as coop_bp
from .inspection import bp as inspection_bp
from .sampling import bp as sampling_bp
from .repair import bp as repair_bp
from .workhour import bp as workhour_bp
from .todo import bp as todo_bp
from .upload import bp as upload_bp



def register_blueprints(app: Flask):
    app.register_blueprint(auth_bp, url_prefix="/api/v1/auth")
    app.register_blueprint(coop_bp, url_prefix="/api/v1/coop-tasks")
    app.register_blueprint(inspection_bp, url_prefix="/api/v1/inspection-tasks")
    app.register_blueprint(sampling_bp, url_prefix="/api/v1/sampling-tasks")
    app.register_blueprint(repair_bp, url_prefix="/api/v1/repair-tickets")
    app.register_blueprint(workhour_bp, url_prefix="/api/v1/workhours")
    app.register_blueprint(todo_bp, url_prefix="/api/v1/todos")
    app.register_blueprint(upload_bp, url_prefix="/api/v1/uploads")
