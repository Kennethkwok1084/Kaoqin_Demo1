from __future__ import annotations

from flask import Blueprint, g, request

from app.extensions import db
from app.models import RepairMatchApplication, RepairTicket, RepairTicketMember
from app.services.workhour_service import WorkhourService
from app.utils.auth import login_required
from app.utils.response import api_error, api_success

bp = Blueprint("repair", __name__)


@bp.post("")
@login_required()
def create_repair_ticket():
    payload = request.get_json(silent=True) or {}
    ticket = RepairTicket(
        repair_no=payload.get("repair_no"),
        ticket_source=payload["ticket_source"],
        title=payload.get("title"),
        report_user_name=payload.get("report_user_name"),
        report_phone=payload.get("report_phone"),
        building_id=payload.get("building_id"),
        dorm_room_id=payload.get("dorm_room_id"),
        issue_content=payload.get("issue_content"),
        issue_category=payload.get("issue_category"),
        solution_desc=payload.get("solution_desc"),
        solve_status=payload.get("solve_status", 0),
        source_screenshot_id=payload.get("source_screenshot_id"),
        doorplate_image_id=payload.get("doorplate_image_id"),
        ocr_payload=payload.get("ocr_payload"),
        match_status=0,
        created_by=g.current_user.id,
    )
    db.session.add(ticket)
    db.session.flush()

    for member in payload.get("members", []):
        db.session.add(
            RepairTicketMember(
                repair_ticket_id=ticket.id,
                user_id=member["user_id"],
                member_role=member.get("member_role", "assist"),
            )
        )

    for member in payload.get("members", []):
        WorkhourService.create_entry(
            biz_type="repair",
            biz_id=ticket.id,
            user_id=member["user_id"],
            base_minutes=int(payload.get("base_minutes", 0)),
        )

    db.session.commit()
    return api_success(ticket.to_dict(), message="报修单创建成功", http_status=201)


@bp.post("/<int:ticket_id>/match-application")
@login_required()
def apply_match(ticket_id: int):
    payload = request.get_json(silent=True) or {}
    import_repair_row_id = payload.get("import_repair_row_id")
    if not import_repair_row_id:
        return api_error("import_repair_row_id 不能为空", code=4001)

    entity = RepairMatchApplication(
        repair_ticket_id=ticket_id,
        import_repair_row_id=import_repair_row_id,
        applied_by=g.current_user.id,
        apply_note=payload.get("apply_note"),
        status=0,
    )
    db.session.add(entity)

    ticket = RepairTicket.query.get(ticket_id)
    if ticket:
        ticket.match_status = 1

    db.session.commit()
    return api_success(entity.to_dict(), message="匹配申请已提交", http_status=201)
