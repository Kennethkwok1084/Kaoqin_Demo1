from __future__ import annotations

from flask import Blueprint, g, request

from app.extensions import db
from app.models import InspectionRecord, TaskInspection, TaskInspectionPoint, TaskInspectionUser, TodoItem
from app.services.workhour_service import WorkhourService
from app.utils.auth import login_required
from app.utils.response import api_error, api_success

bp = Blueprint("inspection", __name__)


@bp.post("")
@login_required(role="admin")
def create_inspection_task():
    payload = request.get_json(silent=True) or {}
    task = TaskInspection(
        task_code=payload["task_code"],
        title=payload["title"],
        description=payload.get("description"),
        building_id=payload.get("building_id"),
        planned_start_at=payload.get("planned_start_at"),
        planned_end_at=payload.get("planned_end_at"),
        assigned_by=g.current_user.id,
        status=payload.get("status", 1),
    )
    db.session.add(task)
    db.session.flush()

    for user_id in payload.get("assignee_user_ids", []):
        db.session.add(TaskInspectionUser(inspection_task_id=task.id, user_id=user_id, role_in_task="executor", status=1))

    for idx, point in enumerate(payload.get("points", []), start=1):
        db.session.add(
            TaskInspectionPoint(
                inspection_task_id=task.id,
                cabinet_name=point["cabinet_name"],
                cabinet_location=point.get("cabinet_location"),
                sort_no=point.get("sort_no", idx),
                is_mandatory_photo=point.get("is_mandatory_photo", True),
            )
        )
    db.session.commit()
    return api_success(task.to_dict(), message="巡检任务创建成功", http_status=201)


@bp.post("/<int:task_id>/records")
@login_required()
def submit_inspection_record(task_id: int):
    payload = request.get_json(silent=True) or {}
    point_id = payload.get("inspection_point_id")
    if not point_id:
        return api_error("inspection_point_id 不能为空", code=4001)

    record = InspectionRecord(
        inspection_task_id=task_id,
        inspection_point_id=point_id,
        user_id=g.current_user.id,
        result_status=payload.get("result_status", 1),
        exception_type=payload.get("exception_type"),
        exception_desc=payload.get("exception_desc"),
        handled_desc=payload.get("handled_desc"),
        media_image_id=payload.get("media_image_id"),
        media_video_id=payload.get("media_video_id"),
        submitted_at=payload.get("submitted_at") or db.func.now(),
        review_status=0,
    )
    db.session.add(record)
    db.session.flush()

    if record.result_status == 2:
        db.session.add(
            TodoItem(
                todo_type="inspection_exception",
                source_biz_type="inspection_record",
                source_biz_id=record.id,
                title=f"巡检异常待处理: #{record.id}",
                content=record.exception_desc,
                priority_level=2,
                status=0,
            )
        )

    WorkhourService.create_entry(
        biz_type="inspection",
        biz_id=record.id,
        user_id=g.current_user.id,
        base_minutes=int(payload.get("base_minutes", 0)),
    )
    db.session.commit()
    return api_success(record.to_dict(), message="巡检记录提交成功", http_status=201)
