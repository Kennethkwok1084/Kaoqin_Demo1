from __future__ import annotations

from pathlib import Path
from uuid import uuid4

from flask import Blueprint, current_app, g, request

from app.extensions import db
from app.models import MediaFile
from app.utils.auth import login_required
from app.utils.response import api_error, api_success

bp = Blueprint("upload", __name__)


@bp.post("")
@login_required()
def upload_file():
    file = request.files.get("file")
    biz_type = request.form.get("biz_type")
    biz_id = request.form.get("biz_id")
    file_type = request.form.get("file_type", "other")
    if not file or not biz_type or not biz_id:
        return api_error("file、biz_type、biz_id 不能为空", code=4001)

    upload_dir = Path(current_app.root_path).parent / "storage" / biz_type / str(biz_id)
    upload_dir.mkdir(parents=True, exist_ok=True)
    save_name = f"{uuid4().hex}_{file.filename}"
    save_path = upload_dir / save_name
    file.save(save_path)

    media = MediaFile(
        biz_type=biz_type,
        biz_id=int(biz_id),
        file_type=file_type,
        storage_path=str(save_path),
        file_name=file.filename,
        content_type=file.content_type,
        file_size=save_path.stat().st_size,
        uploaded_by=g.current_user.id,
    )
    db.session.add(media)
    db.session.commit()
    return api_success(media.to_dict(), message="上传成功", http_status=201)
