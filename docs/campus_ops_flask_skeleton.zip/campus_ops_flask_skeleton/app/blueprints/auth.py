from __future__ import annotations

from flask import Blueprint, request

from app.extensions import db
from app.models import AppUser
from app.utils.auth import encode_token, login_required
from app.utils.response import api_error, api_success

bp = Blueprint("auth", __name__)


@bp.post("/login")
def login():
    payload = request.get_json(silent=True) or {}
    student_no = payload.get("student_no")
    password = payload.get("password")
    if not student_no or not password:
        return api_error("student_no 和 password 不能为空", code=4001)

    user = AppUser.query.filter_by(student_no=student_no, status=1).first()
    if not user:
        return api_error("账号不存在或已禁用", code=4004, http_status=404)

    # 示例骨架：这里应替换成实际密码校验逻辑
    if user.password_hash != password:
        return api_error("密码错误", code=4005, http_status=401)

    token = encode_token(user.id, user.role_code)
    user.last_login_at = db.func.now()
    db.session.commit()
    return api_success({"access_token": token, "user": user.to_dict()}, message="登录成功")


@bp.get("/me")
@login_required()
def me():
    from flask import g

    return api_success(g.current_user.to_dict())
