from __future__ import annotations

from flask import Blueprint, g, request

from app.extensions import db
from app.models import TaskCoop, TaskCoopSlot, TaskCoopSignup, TaskCoopAttendance
from app.services.workhour_service import WorkhourService
from app.utils.auth import login_required
from app.utils.pagination import build_page_payload
from app.utils.response import api_error, api_success

bp = Blueprint("coop", __name__)


@bp.get("")
@login_required()
def list_tasks():
    page = max(int(request.args.get("page", 1)), 1)
    page_size = min(max(int(request.args.get("page_size", 20)), 1), 100)
    query = TaskCoop.query.order_by(TaskCoop.created_at.desc())
    total = query.count()
    rows = query.offset((page - 1) * page_size).limit(page_size).all()
    return api_success(build_page_payload([row.to_dict() for row in rows], page, page_size, total))


@bp.post("")
@login_required(role="admin")
def create_task():
    payload = request.get_json(silent=True) or {}
    task = TaskCoop(
        task_code=payload["task_code"],
        title=payload["title"],
        description=payload.get("description"),
        location_text=payload.get("location_text"),
        building_id=payload.get("building_id"),
        signup_need_review=payload.get("signup_need_review", False),
        sign_in_mode_mask=payload.get("sign_in_mode_mask", 0),
        no_show_enabled=payload.get("no_show_enabled", True),
        status=payload.get("status", 0),
        created_by=g.current_user.id,
    )
    db.session.add(task)
    db.session.flush()

    for idx, slot in enumerate(payload.get("slots", []), start=1):
        db.session.add(
            TaskCoopSlot(
                coop_task_id=task.id,
                slot_title=slot.get("slot_title"),
                start_time=slot["start_time"],
                end_time=slot["end_time"],
                signup_limit=slot.get("signup_limit", 1),
                sort_no=slot.get("sort_no", idx),
            )
        )

    db.session.commit()
    return api_success(task.to_dict(), message="协助任务创建成功", http_status=201)


@bp.post("/<int:task_id>/signups")
@login_required()
def signup(task_id: int):
    payload = request.get_json(silent=True) or {}
    slot_id = payload.get("slot_id")
    if not slot_id:
        return api_error("slot_id 不能为空", code=4001)

    exists = TaskCoopSignup.query.filter_by(coop_slot_id=slot_id, user_id=g.current_user.id).first()
    if exists:
        return api_error("你已经报名过该时间段", code=4091, http_status=409)

    signup = TaskCoopSignup(
        coop_task_id=task_id,
        coop_slot_id=slot_id,
        user_id=g.current_user.id,
        signup_source="self",
        status=1,
    )
    db.session.add(signup)
    db.session.commit()
    return api_success(signup.to_dict(), message="报名成功", http_status=201)


@bp.post("/signups/<int:signup_id>/attendance")
@login_required()
def submit_attendance(signup_id: int):
    payload = request.get_json(silent=True) or {}
    attendance = TaskCoopAttendance.query.filter_by(coop_signup_id=signup_id).first()
    if not attendance:
        attendance = TaskCoopAttendance(coop_signup_id=signup_id)
        db.session.add(attendance)

    action = payload.get("action", "sign_in")
    if action == "sign_in":
        attendance.sign_in_at = payload.get("sign_in_at")
        attendance.sign_in_type = payload.get("sign_in_type")
        attendance.sign_in_longitude = payload.get("sign_in_longitude")
        attendance.sign_in_latitude = payload.get("sign_in_latitude")
    elif action == "sign_out":
        attendance.sign_out_at = payload.get("sign_out_at")
        attendance.sign_out_type = payload.get("sign_out_type")
        attendance.sign_out_longitude = payload.get("sign_out_longitude")
        attendance.sign_out_latitude = payload.get("sign_out_latitude")
        duration_minutes = int(payload.get("duration_minutes", 0))
        attendance.duration_minutes = duration_minutes
        WorkhourService.create_entry(
            biz_type="coop",
            biz_id=signup_id,
            user_id=g.current_user.id,
            base_minutes=duration_minutes,
        )
    else:
        return api_error("不支持的 attendance action", code=4002)

    db.session.commit()
    return api_success(attendance.to_dict(), message="签到记录已保存")
