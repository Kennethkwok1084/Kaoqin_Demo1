from __future__ import annotations

from flask import Blueprint, request

from app.models import WorkhourEntry
from app.utils.auth import login_required
from app.utils.pagination import build_page_payload
from app.utils.response import api_success

bp = Blueprint("workhour", __name__)


@bp.get("")
@login_required()
def list_workhours():
    from flask import g

    page = max(int(request.args.get("page", 1)), 1)
    page_size = min(max(int(request.args.get("page_size", 20)), 1), 100)

    query = WorkhourEntry.query.order_by(WorkhourEntry.created_at.desc())
    if g.current_user.role_code != "admin":
        query = query.filter(WorkhourEntry.user_id == g.current_user.id)

    total = query.count()
    rows = query.offset((page - 1) * page_size).limit(page_size).all()
    return api_success(build_page_payload([row.to_dict() for row in rows], page, page_size, total))
