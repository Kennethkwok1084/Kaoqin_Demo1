from __future__ import annotations

from psycopg.rows import dict_row

from app.extensions import raw_pool


class SamplingRepository:
    @staticmethod
    def list_recent_records(limit: int = 20):
        sql = """
        SELECT sr.id,
               sr.sampling_task_id,
               sr.dorm_room_id,
               sr.user_id,
               sr.current_ssid,
               sr.current_bssid,
               sr.down_speed_mbps,
               sr.up_speed_mbps,
               sr.internet_ping_ms,
               sr.created_at
          FROM sampling_record sr
      ORDER BY sr.created_at DESC
         LIMIT %s
        """
        assert raw_pool is not None
        with raw_pool.connection() as conn:
            with conn.cursor(row_factory=dict_row) as cur:
                cur.execute(sql, (limit,))
                return cur.fetchall()
