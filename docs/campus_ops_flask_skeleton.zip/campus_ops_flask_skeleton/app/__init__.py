from __future__ import annotations

import uuid

from flask import Flask, g, request
from psycopg_pool import ConnectionPool

from app.config import get_config
from app.extensions import db
from app.blueprints import register_blueprints


def create_app() -> Flask:
    app = Flask(__name__)
    app.config.from_object(get_config())

    db.init_app(app)

    # 延迟导入，确保模型已注册
    from app import models  # noqa: F401
    from app.extensions import raw_pool
    import app.extensions as ext

    ext.raw_pool = ConnectionPool(conninfo=app.config["RAW_DATABASE_DSN"], open=False)
    ext.raw_pool.open(wait=True)

    @app.before_request
    def inject_request_id():
        g.request_id = request.headers.get("X-Request-Id") or str(uuid.uuid4())

    @app.get("/healthz")
    def healthz():
        return {"ok": True, "request_id": g.request_id}

    register_blueprints(app)
    return app
