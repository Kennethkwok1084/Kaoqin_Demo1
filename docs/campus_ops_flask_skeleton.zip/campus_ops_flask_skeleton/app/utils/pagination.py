from __future__ import annotations

from math import ceil


def build_page_payload(items, page: int, page_size: int, total: int):
    pages = ceil(total / page_size) if page_size else 0
    return {
        "items": items,
        "pagination": {
            "page": page,
            "page_size": page_size,
            "total": total,
            "pages": pages,
            "has_next": page < pages,
            "has_prev": page > 1,
        },
    }
