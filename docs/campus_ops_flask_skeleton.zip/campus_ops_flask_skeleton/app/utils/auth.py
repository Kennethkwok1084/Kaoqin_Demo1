from __future__ import annotations

from functools import wraps
from typing import Callable

from flask import current_app, g, request
import jwt

from app.models import AppUser
from app.utils.response import api_error


class AuthError(Exception):
    pass



def encode_token(user_id: int, role_code: str) -> str:
    return jwt.encode(
        {"user_id": user_id, "role_code": role_code},
        current_app.config["JWT_SECRET"],
        algorithm="HS256",
    )



def decode_token(token: str) -> dict:
    return jwt.decode(token, current_app.config["JWT_SECRET"], algorithms=["HS256"])



def login_required(role: str | None = None):
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            auth_header = request.headers.get("Authorization", "")
            if not auth_header.startswith("Bearer "):
                return api_error("未提供有效登录令牌", code=4010, http_status=401)
            token = auth_header.replace("Bearer ", "", 1).strip()
            try:
                payload = decode_token(token)
            except Exception:
                return api_error("登录令牌无效或已过期", code=4011, http_status=401)

            user = AppUser.query.get(payload["user_id"])
            if not user or user.status != 1:
                return api_error("用户不存在或已被禁用", code=4012, http_status=401)
            if role and user.role_code != role:
                return api_error("没有访问权限", code=4030, http_status=403)
            g.current_user = user
            return func(*args, **kwargs)

        return wrapper

    return decorator
