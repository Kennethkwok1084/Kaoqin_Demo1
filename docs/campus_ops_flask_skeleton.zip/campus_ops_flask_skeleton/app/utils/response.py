from __future__ import annotations

from flask import jsonify, g


def api_success(data=None, message: str = "ok", code: int = 0, http_status: int = 200):
    return (
        jsonify(
            {
                "code": code,
                "message": message,
                "data": data,
                "request_id": getattr(g, "request_id", None),
            }
        ),
        http_status,
    )



def api_error(message: str, code: int = 4000, http_status: int = 400, data=None):
    return (
        jsonify(
            {
                "code": code,
                "message": message,
                "data": data,
                "request_id": getattr(g, "request_id", None),
            }
        ),
        http_status,
    )
