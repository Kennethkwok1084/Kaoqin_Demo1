from __future__ import annotations

from app.extensions import db
from app.models import WorkhourEntry


class WorkhourService:
    @staticmethod
    def create_entry(*, biz_type: str, biz_id: int, user_id: int, base_minutes: int, final_minutes: int | None = None):
        entry = WorkhourEntry(
            biz_type=biz_type,
            biz_id=biz_id,
            user_id=user_id,
            base_minutes=base_minutes,
            final_minutes=final_minutes if final_minutes is not None else base_minutes,
            review_status=0,
        )
        db.session.add(entry)
        db.session.flush()
        return entry
