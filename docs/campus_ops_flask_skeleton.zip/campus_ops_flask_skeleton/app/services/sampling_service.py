from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone

from app.extensions import db
from app.models import DormRoom, TaskSampling, TaskSamplingRoom


class SamplingService:
    @staticmethod
    def generate_rooms(task: TaskSampling) -> list[TaskSamplingRoom]:
        cutoff = datetime.now(timezone.utc) - timedelta(days=task.exclude_days)
        candidates = (
            DormRoom.query.filter(DormRoom.building_id == task.building_id, DormRoom.status == 1)
            .filter((DormRoom.last_sampled_at.is_(None)) | (DormRoom.last_sampled_at < cutoff))
            .all()
        )
        if not candidates:
            return []

        weighted_pool: list[DormRoom] = []
        for room in candidates:
            weight = max(1, int(room.active_repair_weight or 0) + 1)
            weighted_pool.extend([room] * weight)

        selected: list[DormRoom] = []
        selected_ids: set[int] = set()
        while weighted_pool and len(selected) < task.target_room_count:
            room = random.choice(weighted_pool)
            weighted_pool = [item for item in weighted_pool if item.id != room.id]
            if room.id in selected_ids:
                continue
            selected.append(room)
            selected_ids.add(room.id)

        result = []
        for room in selected:
            entity = TaskSamplingRoom(
                sampling_task_id=task.id,
                dorm_room_id=room.id,
                generated_weight=room.active_repair_weight,
                is_completed=False,
            )
            db.session.add(entity)
            result.append(entity)
        db.session.flush()
        return result
