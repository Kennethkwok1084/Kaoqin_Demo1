from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, Boolean, CheckConstraint, DateTime, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from .base import SerializerMixin, TimestampMixin


class TaskSampling(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "task_sampling"
    __table_args__ = (
        CheckConstraint("sample_strategy IN ('weighted_random')", name="ck_task_sampling_strategy"),
        CheckConstraint("status IN (0,1,2,3,4,5)", name="ck_task_sampling_status"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    task_code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    building_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("building.id", ondelete="RESTRICT"), nullable=False)
    target_room_count: Mapped[int] = mapped_column(Integer, nullable=False)
    sample_strategy: Mapped[str] = mapped_column(String(32), default="weighted_random", nullable=False)
    exclude_days: Mapped[int] = mapped_column(Integer, default=30, nullable=False)
    assigned_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    planned_start_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    planned_end_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    status: Mapped[int] = mapped_column(default=1, nullable=False)


class TaskSamplingUser(db.Model, SerializerMixin):
    __tablename__ = "task_sampling_user"
    __table_args__ = (
        UniqueConstraint("sampling_task_id", "user_id", name="uq_task_sampling_user"),
        CheckConstraint("role_in_task IN ('leader','executor')", name="ck_task_sampling_user_role"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    sampling_task_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_sampling.id", ondelete="CASCADE"), nullable=False)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    role_in_task: Mapped[str] = mapped_column(String(16), default="executor", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class TaskSamplingRoom(db.Model, SerializerMixin):
    __tablename__ = "task_sampling_room"
    __table_args__ = (
        UniqueConstraint("sampling_task_id", "dorm_room_id", name="uq_task_sampling_room"),
        Index("idx_task_sampling_room_task", "sampling_task_id", "is_completed"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    sampling_task_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_sampling.id", ondelete="CASCADE"), nullable=False)
    dorm_room_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("dorm_room.id", ondelete="RESTRICT"), nullable=False)
    generated_weight: Mapped[int] = mapped_column(default=0, nullable=False)
    is_completed: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    completed_by: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="SET NULL"))
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class SamplingRecord(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "sampling_record"
    __table_args__ = (
        CheckConstraint("detect_mode IN ('full','single_item')", name="ck_sampling_record_mode"),
        CheckConstraint("review_status IN (0,1,2)", name="ck_sampling_record_review"),
        Index("idx_sampling_record_task_user", "sampling_task_id", "user_id", "created_at"),
        Index("idx_sampling_record_room", "dorm_room_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    sampling_task_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_sampling.id", ondelete="CASCADE"), nullable=False)
    sampling_task_room_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_sampling_room.id", ondelete="CASCADE"), nullable=False)
    dorm_room_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("dorm_room.id", ondelete="RESTRICT"), nullable=False)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    detect_mode: Mapped[str] = mapped_column(String(16), default="full", nullable=False)
    current_ssid: Mapped[Optional[str]] = mapped_column(String(64))
    current_bssid: Mapped[Optional[str]] = mapped_column(String(64))
    bssid_match: Mapped[Optional[bool]] = mapped_column(Boolean)
    ipv4_addr: Mapped[Optional[str]] = mapped_column(String(64))
    gateway_addr: Mapped[Optional[str]] = mapped_column(String(64))
    dns_list: Mapped[Optional[list]] = mapped_column(JSONB)
    operator_name: Mapped[Optional[str]] = mapped_column(String(64))
    channel_no: Mapped[Optional[int]] = mapped_column(Integer)
    negotiated_rate_mbps: Mapped[Optional[float]] = mapped_column(Numeric(10, 2))
    signal_strength_dbm: Mapped[Optional[int]] = mapped_column(Integer)
    loss_rate_pct: Mapped[Optional[float]] = mapped_column(Numeric(5, 2))
    intranet_ping_ms: Mapped[Optional[float]] = mapped_column(Numeric(10, 2))
    internet_ping_ms: Mapped[Optional[float]] = mapped_column(Numeric(10, 2))
    udp_jitter_ms: Mapped[Optional[float]] = mapped_column(Numeric(10, 2))
    udp_loss_rate_pct: Mapped[Optional[float]] = mapped_column(Numeric(5, 2))
    tcp_rtt_ms: Mapped[Optional[float]] = mapped_column(Numeric(10, 2))
    down_speed_mbps: Mapped[Optional[float]] = mapped_column(Numeric(10, 2))
    up_speed_mbps: Mapped[Optional[float]] = mapped_column(Numeric(10, 2))
    interference_score: Mapped[Optional[float]] = mapped_column(Numeric(10, 2))
    exception_auto: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    exception_manual: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    manual_exception_note: Mapped[Optional[str]] = mapped_column(Text)
    review_status: Mapped[int] = mapped_column(default=0, nullable=False)
    reviewed_by: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="SET NULL"))
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))


class SamplingScanDetail(db.Model, SerializerMixin):
    __tablename__ = "sampling_scan_detail"
    __table_args__ = (Index("idx_sampling_scan_detail_record", "sampling_record_id"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    sampling_record_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("sampling_record.id", ondelete="CASCADE"), nullable=False)
    ssid: Mapped[Optional[str]] = mapped_column(String(128))
    bssid: Mapped[Optional[str]] = mapped_column(String(64))
    channel_no: Mapped[Optional[int]] = mapped_column(Integer)
    signal_strength_dbm: Mapped[Optional[int]] = mapped_column(Integer)
    is_same_channel: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_adjacent_channel: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class SamplingTestDetail(db.Model, SerializerMixin):
    __tablename__ = "sampling_test_detail"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    sampling_record_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("sampling_record.id", ondelete="CASCADE"), nullable=False)
    item_code: Mapped[str] = mapped_column(String(32), nullable=False)
    target_host: Mapped[Optional[str]] = mapped_column(String(255))
    result_payload: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    save_to_record: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
