from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, CheckConstraint, DateTime, ForeignKey, Index, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from .base import SerializerMixin, TimestampMixin


class TaskInspection(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "task_inspection"
    __table_args__ = (CheckConstraint("status IN (0,1,2,3,4,5)", name="ck_task_inspection_status"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    task_code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    building_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("building.id", ondelete="SET NULL"))
    planned_start_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    planned_end_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    assigned_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    status: Mapped[int] = mapped_column(default=1, nullable=False)


class TaskInspectionUser(db.Model, SerializerMixin):
    __tablename__ = "task_inspection_user"
    __table_args__ = (
        UniqueConstraint("inspection_task_id", "user_id", name="uq_task_inspection_user"),
        CheckConstraint("role_in_task IN ('leader','executor')", name="ck_task_inspection_user_role"),
        CheckConstraint("status IN (0,1)", name="ck_task_inspection_user_status"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    inspection_task_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_inspection.id", ondelete="CASCADE"), nullable=False)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    role_in_task: Mapped[str] = mapped_column(String(16), default="executor", nullable=False)
    status: Mapped[int] = mapped_column(default=1, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class TaskInspectionPoint(db.Model, SerializerMixin):
    __tablename__ = "task_inspection_point"
    __table_args__ = (Index("idx_task_inspection_point_task", "inspection_task_id", "sort_no"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    inspection_task_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_inspection.id", ondelete="CASCADE"), nullable=False)
    cabinet_name: Mapped[str] = mapped_column(String(128), nullable=False)
    cabinet_location: Mapped[Optional[str]] = mapped_column(String(255))
    sort_no: Mapped[int] = mapped_column(default=1, nullable=False)
    is_mandatory_photo: Mapped[bool] = mapped_column(default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class InspectionRecord(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "inspection_record"
    __table_args__ = (
        UniqueConstraint("inspection_task_id", "inspection_point_id", "user_id", name="uq_inspection_record_task_point_user"),
        CheckConstraint("result_status IN (1,2,3)", name="ck_inspection_record_result"),
        CheckConstraint("review_status IN (0,1,2)", name="ck_inspection_record_review"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    inspection_task_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_inspection.id", ondelete="CASCADE"), nullable=False)
    inspection_point_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_inspection_point.id", ondelete="CASCADE"), nullable=False)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    result_status: Mapped[int] = mapped_column(default=1, nullable=False)
    exception_type: Mapped[Optional[str]] = mapped_column(String(64))
    exception_desc: Mapped[Optional[str]] = mapped_column(Text)
    handled_desc: Mapped[Optional[str]] = mapped_column(Text)
    media_image_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("media_file.id", ondelete="SET NULL"))
    media_video_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("media_file.id", ondelete="SET NULL"))
    submitted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    reviewed_by: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="SET NULL"))
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    review_status: Mapped[int] = mapped_column(default=0, nullable=False)
