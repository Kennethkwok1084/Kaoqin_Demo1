from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, CheckConstraint, DateTime, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from .base import SerializerMixin, TimestampMixin


class TaskCoop(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "task_coop"
    __table_args__ = (
        CheckConstraint("status IN (0,1,2,3,4,5)", name="ck_task_coop_status"),
        Index("idx_task_coop_status_time", "status", "published_at"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    task_code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    location_text: Mapped[Optional[str]] = mapped_column(String(255))
    building_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("building.id", ondelete="SET NULL"))
    signup_need_review: Mapped[bool] = mapped_column(default=False, nullable=False)
    sign_in_mode_mask: Mapped[int] = mapped_column(default=0, nullable=False)
    no_show_enabled: Mapped[bool] = mapped_column(default=True, nullable=False)
    status: Mapped[int] = mapped_column(default=0, nullable=False)
    created_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    published_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))


class TaskCoopSlot(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "task_coop_slot"
    __table_args__ = (
        CheckConstraint("end_time > start_time", name="ck_task_coop_slot_time"),
        CheckConstraint("status IN (0,1)", name="ck_task_coop_slot_status"),
        Index("idx_task_coop_slot_task", "coop_task_id", "start_time"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    coop_task_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_coop.id", ondelete="CASCADE"), nullable=False)
    slot_title: Mapped[Optional[str]] = mapped_column(String(128))
    start_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    end_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    signup_limit: Mapped[int] = mapped_column(default=1, nullable=False)
    sort_no: Mapped[int] = mapped_column(default=1, nullable=False)
    status: Mapped[int] = mapped_column(default=1, nullable=False)


class TaskCoopSignup(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "task_coop_signup"
    __table_args__ = (
        UniqueConstraint("coop_slot_id", "user_id", name="uq_task_coop_signup_slot_user"),
        CheckConstraint("signup_source IN ('self','assign')", name="ck_task_coop_signup_source"),
        CheckConstraint("status IN (0,1,2,3,4)", name="ck_task_coop_signup_status"),
        Index("idx_task_coop_signup_user", "user_id", "status"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    coop_task_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_coop.id", ondelete="CASCADE"), nullable=False)
    coop_slot_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_coop_slot.id", ondelete="CASCADE"), nullable=False)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    signup_source: Mapped[str] = mapped_column(String(16), default="self", nullable=False)
    status: Mapped[int] = mapped_column(default=1, nullable=False)
    reviewed_by: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="SET NULL"))
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    cancel_reason: Mapped[Optional[str]] = mapped_column(Text)


class TaskCoopAttendance(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "task_coop_attendance"
    __table_args__ = (
        CheckConstraint(
            "sign_in_type IN ('gps','qr','manual','admin','hybrid') OR sign_in_type IS NULL",
            name="ck_task_coop_attendance_type",
        ),
        CheckConstraint("review_status IN (0,1,2)", name="ck_task_coop_attendance_review"),
        Index("idx_task_coop_attendance_signup", "coop_signup_id"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    coop_signup_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("task_coop_signup.id", ondelete="CASCADE"), nullable=False)
    sign_in_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    sign_out_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    sign_in_type: Mapped[Optional[str]] = mapped_column(String(16))
    sign_out_type: Mapped[Optional[str]] = mapped_column(String(16))
    sign_in_longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 6))
    sign_in_latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 6))
    sign_out_longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 6))
    sign_out_latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 6))
    qr_token: Mapped[Optional[str]] = mapped_column(String(128))
    admin_confirmed_by: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="SET NULL"))
    admin_confirmed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    duration_minutes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    review_status: Mapped[int] = mapped_column(default=0, nullable=False)
    remark: Mapped[Optional[str]] = mapped_column(Text)
