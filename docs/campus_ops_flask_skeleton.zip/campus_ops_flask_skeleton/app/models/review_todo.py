from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, CheckConstraint, DateTime, ForeignKey, Index, SmallInteger, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from .base import SerializerMixin


class ReviewLog(db.Model, SerializerMixin):
    __tablename__ = "review_log"
    __table_args__ = (Index("idx_review_log_biz", "biz_type", "biz_id", "created_at"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    biz_type: Mapped[str] = mapped_column(String(32), nullable=False)
    biz_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    review_type: Mapped[str] = mapped_column(String(32), nullable=False)
    reviewer_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    action_code: Mapped[str] = mapped_column(String(32), nullable=False)
    review_note: Mapped[Optional[str]] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class TodoItem(db.Model, SerializerMixin):
    __tablename__ = "todo_item"
    __table_args__ = (
        CheckConstraint("priority_level IN (1,2,3,4)", name="ck_todo_item_priority"),
        CheckConstraint("status IN (0,1,2)", name="ck_todo_item_status"),
        Index("idx_todo_item_assignee_status", "assignee_user_id", "status", "created_at"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    todo_type: Mapped[str] = mapped_column(String(32), nullable=False)
    source_biz_type: Mapped[str] = mapped_column(String(32), nullable=False)
    source_biz_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    content: Mapped[Optional[str]] = mapped_column(Text)
    assignee_user_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="SET NULL"))
    priority_level: Mapped[int] = mapped_column(SmallInteger, default=2, nullable=False)
    status: Mapped[int] = mapped_column(SmallInteger, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))


class BizOperationLog(db.Model, SerializerMixin):
    __tablename__ = "biz_operation_log"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    biz_type: Mapped[str] = mapped_column(String(32), nullable=False)
    biz_id: Mapped[Optional[int]] = mapped_column(BigInteger)
    operation_type: Mapped[str] = mapped_column(String(32), nullable=False)
    operator_user_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="SET NULL"))
    request_id: Mapped[Optional[str]] = mapped_column(String(64))
    payload_before: Mapped[Optional[dict]] = mapped_column(JSONB)
    payload_after: Mapped[Optional[dict]] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
