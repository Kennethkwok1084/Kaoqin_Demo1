from __future__ import annotations

from typing import Optional

from sqlalchemy import BigInteger, Boolean, CheckConstraint, ForeignKey, Index, Numeric, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from .base import SerializerMixin, TimestampMixin


class SysConfig(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "sys_config"
    __table_args__ = (UniqueConstraint("config_group", "config_key", name="uq_sys_config_group_key"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    config_group: Mapped[str] = mapped_column(String(64), nullable=False)
    config_key: Mapped[str] = mapped_column(String(128), nullable=False)
    config_value: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class Building(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "building"
    __table_args__ = (CheckConstraint("status IN (0,1)", name="ck_building_status"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    building_code: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    building_name: Mapped[str] = mapped_column(String(128), nullable=False)
    campus_name: Mapped[Optional[str]] = mapped_column(String(128))
    area_name: Mapped[Optional[str]] = mapped_column(String(128))
    longitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 6))
    latitude: Mapped[Optional[float]] = mapped_column(Numeric(10, 6))
    status: Mapped[int] = mapped_column(default=1, nullable=False)


class DormRoom(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "dorm_room"
    __table_args__ = (
        UniqueConstraint("building_id", "room_no", name="uq_dorm_room_building_room"),
        CheckConstraint("status IN (0,1)", name="ck_dorm_room_status"),
        Index("idx_dorm_room_building_status", "building_id", "status"),
        Index("idx_dorm_room_last_sampled", "last_sampled_at"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    building_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("building.id", ondelete="RESTRICT"), nullable=False)
    room_no: Mapped[str] = mapped_column(String(32), nullable=False)
    floor_no: Mapped[Optional[str]] = mapped_column(String(16))
    target_ssid: Mapped[str] = mapped_column(String(64), default="GCC", nullable=False)
    target_bssid: Mapped[str] = mapped_column(String(64), nullable=False)
    dorm_label: Mapped[Optional[str]] = mapped_column(String(128))
    active_repair_weight: Mapped[int] = mapped_column(default=0, nullable=False)
    last_sampled_at: Mapped[Optional[str]] = mapped_column()
    status: Mapped[int] = mapped_column(default=1, nullable=False)
