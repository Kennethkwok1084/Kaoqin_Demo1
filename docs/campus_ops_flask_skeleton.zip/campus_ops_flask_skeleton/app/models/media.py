from __future__ import annotations

from typing import Optional

from sqlalchemy import BigInteger, CheckConstraint, ForeignKey, Index, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from .base import SerializerMixin


class MediaFile(db.Model, SerializerMixin):
    __tablename__ = "media_file"
    __table_args__ = (
        CheckConstraint("file_type IN ('image','video','audio','ocr_source','other')", name="ck_media_file_type"),
        Index("idx_media_file_biz", "biz_type", "biz_id"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    biz_type: Mapped[str] = mapped_column(String(32), nullable=False)
    biz_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    file_type: Mapped[str] = mapped_column(String(16), nullable=False)
    storage_path: Mapped[str] = mapped_column(Text, nullable=False)
    file_name: Mapped[str] = mapped_column(String(255), nullable=False)
    content_type: Mapped[Optional[str]] = mapped_column(String(128))
    file_size: Mapped[int] = mapped_column(BigInteger, default=0, nullable=False)
    sha256_hex: Mapped[Optional[str]] = mapped_column(String(128))
    watermark_payload: Mapped[Optional[dict]] = mapped_column(JSONB)
    uploaded_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
