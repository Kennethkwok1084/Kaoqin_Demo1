from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import DateTime, func
from sqlalchemy.orm import Mapped, mapped_column


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False
    )


class IdMixin:
    id: Mapped[int] = mapped_column(primary_key=True)


class SerializerMixin:
    __serialize_exclude__ = {"password_hash"}

    def to_dict(self) -> dict[str, Any]:
        payload = {}
        exclude = getattr(self, "__serialize_exclude__", set())
        for column in self.__table__.columns:
            if column.name in exclude:
                continue
            value = getattr(self, column.name)
            if hasattr(value, "isoformat"):
                payload[column.name] = value.isoformat()
            else:
                payload[column.name] = value
        return payload
