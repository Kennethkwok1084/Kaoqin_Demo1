from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, CheckConstraint, DateTime, ForeignKey, Index, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.extensions import db
from .base import SerializerMixin, TimestampMixin


class AppUser(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "app_user"
    __table_args__ = (
        CheckConstraint("role_code IN ('admin','user')", name="ck_app_user_role_code"),
        CheckConstraint("status IN (0,1,2)", name="ck_app_user_status"),
        Index("idx_app_user_role_status", "role_code", "status"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    student_no: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    real_name: Mapped[str] = mapped_column(String(64), nullable=False)
    role_code: Mapped[str] = mapped_column(String(16), default="user", nullable=False)
    phone: Mapped[Optional[str]] = mapped_column(String(32))
    email: Mapped[Optional[str]] = mapped_column(String(128))
    avatar_url: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[int] = mapped_column(default=1, nullable=False)
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    remark: Mapped[Optional[str]] = mapped_column(Text)

    profile: Mapped["UserProfile"] = relationship(back_populates="user", uselist=False)


class UserProfile(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "user_profile"
    __table_args__ = (
        CheckConstraint("gender IN (0,1,2) OR gender IS NULL", name="ck_user_profile_gender"),
    )

    user_id: Mapped[int] = mapped_column(
        BigInteger, ForeignKey("app_user.id", ondelete="CASCADE"), primary_key=True
    )
    nickname: Mapped[Optional[str]] = mapped_column(String(64))
    gender: Mapped[Optional[int]] = mapped_column()
    department_name: Mapped[Optional[str]] = mapped_column(String(128))
    grade_name: Mapped[Optional[str]] = mapped_column(String(64))
    class_name: Mapped[Optional[str]] = mapped_column(String(64))
    major_name: Mapped[Optional[str]] = mapped_column(String(128))
    id_card_mask: Mapped[Optional[str]] = mapped_column(String(32))
    emergency_contact: Mapped[Optional[str]] = mapped_column(String(64))
    emergency_phone: Mapped[Optional[str]] = mapped_column(String(32))

    user: Mapped[AppUser] = relationship(back_populates="profile")


class AuthRefreshToken(db.Model, SerializerMixin):
    __tablename__ = "auth_refresh_token"
    __table_args__ = (
        Index("idx_refresh_token_user", "user_id"),
        Index("idx_refresh_token_expires", "expires_at"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="CASCADE"), nullable=False)
    refresh_token: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    device_id: Mapped[Optional[str]] = mapped_column(String(128))
    device_name: Mapped[Optional[str]] = mapped_column(String(128))
    platform_code: Mapped[Optional[str]] = mapped_column(String(32))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
