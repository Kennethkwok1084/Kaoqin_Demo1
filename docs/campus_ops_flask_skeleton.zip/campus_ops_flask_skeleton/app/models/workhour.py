from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, Boolean, CheckConstraint, DateTime, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from .base import SerializerMixin, TimestampMixin


class WorkhourRule(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "workhour_rule"
    __table_args__ = (CheckConstraint("biz_type IN ('coop','inspection','sampling','repair')", name="ck_workhour_rule_biz"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    rule_code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    rule_name: Mapped[str] = mapped_column(String(128), nullable=False)
    biz_type: Mapped[str] = mapped_column(String(32), nullable=False)
    formula_desc: Mapped[str] = mapped_column(Text, nullable=False)
    formula_json: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class WorkhourTag(db.Model, SerializerMixin):
    __tablename__ = "workhour_tag"
    __table_args__ = (
        CheckConstraint("tag_type IN ('good_review','burst_order','custom')", name="ck_workhour_tag_type"),
        CheckConstraint("bonus_mode IN ('add','multiply')", name="ck_workhour_tag_bonus_mode"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    tag_code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    tag_name: Mapped[str] = mapped_column(String(128), nullable=False)
    tag_type: Mapped[str] = mapped_column(String(32), nullable=False)
    bonus_mode: Mapped[str] = mapped_column(String(16), default="add", nullable=False)
    bonus_value: Mapped[float] = mapped_column(Numeric(10, 2), default=0, nullable=False)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class WorkhourEntry(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "workhour_entry"
    __table_args__ = (
        CheckConstraint("biz_type IN ('coop','inspection','sampling','repair')", name="ck_workhour_entry_biz"),
        CheckConstraint("review_status IN (0,1,2)", name="ck_workhour_entry_review"),
        Index("idx_workhour_entry_user_time", "user_id", "created_at"),
        Index("idx_workhour_entry_biz", "biz_type", "biz_id"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    biz_type: Mapped[str] = mapped_column(String(32), nullable=False)
    biz_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    source_rule_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("workhour_rule.id", ondelete="SET NULL"))
    base_minutes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    final_minutes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    review_status: Mapped[int] = mapped_column(default=0, nullable=False)
    reviewed_by: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="SET NULL"))
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    review_note: Mapped[Optional[str]] = mapped_column(Text)


class WorkhourEntryTag(db.Model, SerializerMixin):
    __tablename__ = "workhour_entry_tag"
    __table_args__ = (UniqueConstraint("workhour_entry_id", "workhour_tag_id", name="uq_workhour_entry_tag"),)

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    workhour_entry_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("workhour_entry.id", ondelete="CASCADE"), nullable=False)
    workhour_tag_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("workhour_tag.id", ondelete="RESTRICT"), nullable=False)
    bonus_minutes: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
