from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, CheckConstraint, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.extensions import db
from .base import SerializerMixin, TimestampMixin


class RepairTicket(db.Model, TimestampMixin, SerializerMixin):
    __tablename__ = "repair_ticket"
    __table_args__ = (
        CheckConstraint("ticket_source IN ('online','offline')", name="ck_repair_ticket_source"),
        CheckConstraint("solve_status IN (0,1,2)", name="ck_repair_ticket_solve_status"),
        CheckConstraint("match_status IN (0,1,2,3)", name="ck_repair_ticket_match_status"),
        Index("idx_repair_ticket_no", "repair_no"),
        Index("idx_repair_ticket_source_status", "ticket_source", "match_status", "created_at"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    repair_no: Mapped[Optional[str]] = mapped_column(String(64))
    ticket_source: Mapped[str] = mapped_column(String(16), nullable=False)
    title: Mapped[Optional[str]] = mapped_column(String(255))
    report_user_name: Mapped[Optional[str]] = mapped_column(String(64))
    report_phone: Mapped[Optional[str]] = mapped_column(String(32))
    building_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("building.id", ondelete="SET NULL"))
    dorm_room_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("dorm_room.id", ondelete="SET NULL"))
    issue_content: Mapped[Optional[str]] = mapped_column(Text)
    issue_category: Mapped[Optional[str]] = mapped_column(String(64))
    solution_desc: Mapped[Optional[str]] = mapped_column(Text)
    solve_status: Mapped[int] = mapped_column(default=0, nullable=False)
    source_screenshot_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("media_file.id", ondelete="SET NULL"))
    doorplate_image_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("media_file.id", ondelete="SET NULL"))
    ocr_payload: Mapped[Optional[dict]] = mapped_column(JSONB)
    match_status: Mapped[int] = mapped_column(default=0, nullable=False)
    matched_import_row_id: Mapped[Optional[int]] = mapped_column(BigInteger)
    created_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)


class RepairTicketMember(db.Model, SerializerMixin):
    __tablename__ = "repair_ticket_member"
    __table_args__ = (
        UniqueConstraint("repair_ticket_id", "user_id", name="uq_repair_ticket_member"),
        CheckConstraint("member_role IN ('primary','assist')", name="ck_repair_ticket_member_role"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    repair_ticket_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("repair_ticket.id", ondelete="CASCADE"), nullable=False)
    user_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    member_role: Mapped[str] = mapped_column(String(16), default="assist", nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class ImportBatch(db.Model, SerializerMixin):
    __tablename__ = "import_batch"
    __table_args__ = (
        CheckConstraint("batch_type IN ('repair_total','repair_legacy','other')", name="ck_import_batch_type"),
        CheckConstraint("status IN (0,1,2,3)", name="ck_import_batch_status"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    batch_type: Mapped[str] = mapped_column(String(32), nullable=False)
    file_name: Mapped[str] = mapped_column(String(255), nullable=False)
    file_storage_path: Mapped[Optional[str]] = mapped_column(Text)
    imported_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    total_rows: Mapped[int] = mapped_column(default=0, nullable=False)
    success_rows: Mapped[int] = mapped_column(default=0, nullable=False)
    failed_rows: Mapped[int] = mapped_column(default=0, nullable=False)
    status: Mapped[int] = mapped_column(default=0, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))


class ImportRepairRow(db.Model, SerializerMixin):
    __tablename__ = "import_repair_row"
    __table_args__ = (
        Index("idx_import_repair_row_no", "repair_no"),
        Index("idx_import_repair_row_match", "matched_ticket_id"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    import_batch_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("import_batch.id", ondelete="CASCADE"), nullable=False)
    repair_no: Mapped[Optional[str]] = mapped_column(String(64))
    report_user_name: Mapped[Optional[str]] = mapped_column(String(64))
    report_phone: Mapped[Optional[str]] = mapped_column(String(32))
    building_name: Mapped[Optional[str]] = mapped_column(String(128))
    room_no: Mapped[Optional[str]] = mapped_column(String(32))
    issue_content: Mapped[Optional[str]] = mapped_column(Text)
    raw_payload: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    matched_ticket_id: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("repair_ticket.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)


class RepairMatchApplication(db.Model, SerializerMixin):
    __tablename__ = "repair_match_application"
    __table_args__ = (
        UniqueConstraint("repair_ticket_id", name="uq_repair_match_application_ticket"),
        CheckConstraint("status IN (0,1,2)", name="ck_repair_match_application_status"),
    )

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    repair_ticket_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("repair_ticket.id", ondelete="CASCADE"), nullable=False)
    import_repair_row_id: Mapped[int] = mapped_column(BigInteger, ForeignKey("import_repair_row.id", ondelete="CASCADE"), nullable=False)
    applied_by: Mapped[int] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="RESTRICT"), nullable=False)
    apply_note: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[int] = mapped_column(default=0, nullable=False)
    reviewed_by: Mapped[Optional[int]] = mapped_column(BigInteger, ForeignKey("app_user.id", ondelete="SET NULL"))
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
