from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class Config:
    SECRET_KEY: str = os.getenv("SECRET_KEY", "dev-secret")
    SQLALCHEMY_DATABASE_URI: str = os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg://postgres:postgres@127.0.0.1:5432/campus_ops",
    )
    RAW_DATABASE_DSN: str = os.getenv(
        "RAW_DATABASE_DSN",
        "postgresql://postgres:postgres@127.0.0.1:5432/campus_ops",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS: bool = False
    JSON_AS_ASCII: bool = False
    JWT_SECRET: str = os.getenv("JWT_SECRET", "jwt-dev-secret")
    DEFAULT_PAGE_SIZE: int = 20
    MAX_PAGE_SIZE: int = 100


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


def get_config() -> type[Config]:
    env = os.getenv("FLASK_ENV", "development").lower()
    if env == "production":
        return ProductionConfig
    return DevelopmentConfig
