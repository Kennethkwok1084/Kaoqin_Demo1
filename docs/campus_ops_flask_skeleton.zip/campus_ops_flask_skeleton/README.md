# 校园网部门综合运维工时平台 Flask 骨架

这是一套基于你当前 V2 需求整理的 Flask 后端示例骨架，目标不是直接替代现有仓库，而是给你一个可以拆进现有项目的参考实现。

## 技术选型

- Flask 3
- SQLAlchemy 2.x（通过 Flask-SQLAlchemy 托管）
- PostgreSQL + psycopg 3
- psycopg_pool 用于原生 SQL / 批量查询 / 高性能读取

## 目录结构

```text
campus_ops_flask_skeleton/
├── app/
│   ├── __init__.py            # app factory
│   ├── config.py             # 配置
│   ├── extensions.py         # db / psycopg_pool
│   ├── blueprints/           # 接口示例
│   ├── models/               # SQLAlchemy 模型映射
│   ├── services/             # 业务服务示例
│   ├── repositories/         # psycopg 原生查询示例
│   └── utils/                # 返回包 / 分页 / 鉴权
├── requirements.txt
├── .env.example
├── run.py
└── README.md
```

## 已覆盖内容

### Flask 接口骨架
- 登录 `/api/v1/auth/login`
- 协助任务创建、列表、报名、签到
- 巡检任务创建、巡检记录提交
- 抽检任务创建、随机宿舍生成、抽检结果提交
- 报修单创建、匹配申请
- 工时列表
- 待办列表
- 上传接口

### SQLAlchemy 模型映射
已按前一版 PostgreSQL 建表脚本拆分为以下领域模型：
- 用户与登录
- 楼栋 / 宿舍基础表
- 媒体文件
- 协助任务
- 巡检任务
- 抽检任务
- 报修单
- 工时规则与工时明细
- 审核日志 / 待办 / 操作日志

### psycopg 原生示例
- `app/repositories/sampling_repository.py`
- 演示如何通过 `psycopg_pool` 跑高频列表查询或批量读取

## 如何使用

1. 安装依赖

```bash
pip install -r requirements.txt
```

2. 配置环境变量

```bash
cp .env.example .env
```

3. 确保 PostgreSQL 已执行你上一版的建表 SQL 文档

4. 启动服务

```bash
python run.py
```

## 接入现有仓库的建议

### 适合直接复用的部分
- `app/utils/response.py`：统一返回包
- `app/utils/auth.py`：鉴权骨架
- `app/services/workhour_service.py`：工时引擎入口骨架
- `app/services/sampling_service.py`：抽检随机宿舍生成
- `app/repositories/sampling_repository.py`：psycopg 原生查询示例

### 需要替换成你现有逻辑的部分
- 密码校验逻辑
- JWT 续签 / refresh token
- 实际权限控制
- 媒体存储（本地/MinIO/OSS）
- 抽检异常阈值读取
- 工时公式细则
- OCR 接口 / 第三方测速 API / iperf3 接口

## 说明

这套骨架更偏“结构参考 + 快速落地”，不是完整业务系统。你后面最适合继续接的是：
1. 把工时引擎细则塞进 `services/workhour_service.py`
2. 把检测阈值和系统配置读取接入 `sys_config`
3. 把登录改成你现有账号体系
4. 把蓝图改造成你仓库的模块风格
